from django.contrib import admin
from .models import Data

@admin.register(Data)
class DataAdmin(admin.ModelAdmin):
    pass
# Register your models here.
